package com.classroom.aulasorte1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //VAMOS CRIAR UM VETOR DE FRASES
    int[] numeros = {
      1,2,3,4,5,6
    };


    //VAMOS CRIAR UM MÉTODO PARA SORTEAR UMA FRASE
    public void sorteiaFrase(View view) {

        // VAMOS CRIAR O CÓDIGO DE SORTEIO COM VALORES ALEATÓRIOS
        int numeroSorteado = new Random().nextInt(5);

        //CRIAMOS REFERÊNCIA PARA ELEMENTO DA INTERFACE

        //TextView txtFrase = findViewById(R.id.textFrase);

        //VAMOS DEFINIR O QUE SERÁ MOSTRADO QUANDO CLICADO NO BOTÃO
        //txtFrase.setText(frases[i]);

        //int fraseSorteada =  frases[i];

        //VAMOS CRIAR A REFERÊNCIA PARA O RESULTADO
        //EditText txtEntrada = findViewById(R.id.editTextFrase);

        //TextView txtRes = findViewById(R.id.textViewResultado);

        //FAZER A VERIFICAÇÃO
    }
}
